
const Alexa = require('alexa-sdk');

//=========================================================================================================================================

var APP_ID = 'your Alexa skill here';

var AWS = require('aws-sdk');
var iotData = new AWS.IotData({endpoint:'your endpoint here});
var topic = "explorer/ledctrl";

const HELP_MESSAGE = 'You can ask me to turn on or off a numbered l e d.';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

var speechOutput;
var reprompt;

//=========================================================================================================================================


var handlers = {
	'LaunchRequest': function () {
		console.log("LaunchRequest called");
        speechOutput = "Hello. How may I help you?";
        reprompt = "";
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
	},

    'LEDZeroOn': function () {
		console.log("LEDZeroOn called");
		var params = {
			topic: topic,
			payload: '{"LED":"0","status":"on"}',
			qos:0
		};
		speechOutput = "I've requested l e d 0 to turn on";
        reprompt = "";
		iotData.publish(params, function(error, data) {
			if (!error){
				console.log("Published LED 0 on");
			}
			else{
				console.log("Error publishing LED 0 on");
			}
		});
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },

    'LEDZeroOff': function () {
		console.log("LEDZeroOff called");
		var params = {
			topic: topic,
			payload: '{"LED":"0","status":"off"}',
			qos:0
		};
		speechOutput = "I've requested l e d 0 to turn off";
        reprompt = "";
		iotData.publish(params, function(error, data) {
			if (!error){
				console.log("Published LED 0 off");
			}
			else{
				console.log("Error publishing LED 0 off");
			}});
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },

    'LEDOneOn': function () {
		console.log("LEDOneOn called");
		var params = {
			topic: topic,
			payload: '{"LED":"1","status":"on"}',
			qos:0
		};
		speechOutput = "I've requested l e d 1 to turn on";
        reprompt = "";
		iotData.publish(params, function(error, data) {
			if (!error){
				console.log("Published LED 1 on");
			}
			else{
				console.log("Error publishing LED 1 on");
			}});
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },

    'LEDOneOff': function () {
		console.log("LEDOneOff called");
		var params = {
			topic: topic,
			payload: '{"LED":"1","status":"off"}',
			qos:0
		};
		speechOutput = "I've requested l e d 1 to turn off";
        reprompt = "";
		iotData.publish(params, function(error, data) {
			if (!error){
				console.log("Published LED 1 off");
			}
			else{
				console.log("Error publishing LED 1 off");
			}});
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },

    'LEDTwoOn': function () {
		console.log("LEDTwoOn called");
		var params = {
			topic: topic,
			payload: '{"LED":"2","status":"on"}',
			qos:0
		};
		speechOutput = "I've requested l e d 2 to turn on";
        reprompt = "";
		iotData.publish(params, function(error, data) {
			if (!error){
				console.log("Published LED 2 on");
			}
			else{
				console.log("Error publishing LED 2 on");
			}});
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },

    'LEDTwoOff': function () {
		console.log("LEDTwoOff called");
		var params = {
			topic: topic,
			payload: '{"LED":"2","status":"off"}',
			qos:0
		};
		speechOutput = "I've requested l e d 2 to turn off";
        reprompt = "";
		iotData.publish(params, function(error, data) {
			if (!error){
				console.log("Published LED 2 off");
			}
			else{
				console.log("Error publishing LED 2 off");
			}});
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },

    'LEDThreeOn': function () {
		console.log("LEDThreeOn called");
		var params = {
			topic: topic,
			payload: '{"LED":"3","status":"on"}',
			qos:0
		};
		speechOutput = "I've requested l e d 3 to turn on";
        reprompt = "";
		iotData.publish(params, function(error, data) {
			if (!error){
				console.log("Published LED 3 on");
			}
			else{
				console.log("Error publishing LED 3 on");
			}});
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },

    'LEDThreeOff': function () {
		console.log("LEDThreeOff called");
		var params = {
			topic: topic,
			payload: '{"LED":"3","status":"off"}',
			qos:0
		};
		speechOutput = "I've requested l e d 3 to turn off";
        reprompt = "";
		iotData.publish(params, function(error, data) {
			if (!error){
				console.log("Published LED 3 off");
			}
			else{
				console.log("Error publishing LED 3 off");
			}});
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },

    'AMAZON.HelpIntent': function () {
		console.log("HelpIntent called");
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;
    
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    
    'AMAZON.CancelIntent': function () {
		console.log("CancelIntent called");
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    
    'AMAZON.StopIntent': function () {
		console.log("StopIntent called");
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    
    'Unhandled': function () {
		console.log("Unhandled called");
        const speechOutput = "Sorry, unhandled request";
        const reprompt = "";
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    }
};

exports.handler = function (event, context, callback) {
    const alexa = Alexa.handler(event, context, callback);
    alexa.appId = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};